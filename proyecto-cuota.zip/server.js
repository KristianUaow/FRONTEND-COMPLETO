import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Utilidad de cálculo (i = mensual en decimal)
function calcularCuota(P, i, n){
  if(n<=0) return NaN;
  if(i === 0) return Math.round(P / n);
  const a = Math.pow(1+i, n);
  return Math.round( P * ( i * a ) / ( a - 1 ) );
}

// POST /api/cuota  → recibe {nombre, prestamo, meses, interesMensual}
app.post('/api/cuota', (req,res)=>{
  try{
    const { nombre, prestamo, meses, interesMensual } = req.body || {};
    if(!nombre || !Number.isFinite(prestamo) || prestamo<=0 || !Number.isInteger(meses) || meses<1 || !Number.isFinite(interesMensual) || interesMensual<0){
      return res.status(400).json({ ok:false, error:'Payload inválido' });
    }
    const cuota = calcularCuota(prestamo, interesMensual, meses);
    const fmt = new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0});
    const salida = `${nombre} debe pagar $ ${fmt.format(cuota)} cada mes por el préstamo de $ ${fmt.format(prestamo)} a ${meses} meses con el interés del ${(interesMensual*100).toFixed(2)}%`;

    // Registro demo en memoria
    if(!app.locals.envios) app.locals.envios = [];
    app.locals.envios.push({ nombre, prestamo, meses, interesMensual, cuota, at: Date.now() });

    return res.json({ ok:true, cuota, salida });
  }catch(err){
    console.error(err);
    return res.status(500).json({ ok:false, error:'Error de servidor' });
  }
});

// GET /api/envios → ver últimos envíos (demo)
app.get('/api/envios', (req,res)=>{
  res.json({ ok:true, total:(app.locals.envios||[]).length, datos: app.locals.envios||[] });
});

app.listen(PORT, ()=> console.log(`Servidor listo en http://localhost:${PORT}`));
